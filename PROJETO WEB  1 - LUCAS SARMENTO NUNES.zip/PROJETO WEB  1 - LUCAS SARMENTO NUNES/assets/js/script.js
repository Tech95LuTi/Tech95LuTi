function toggleMenu(){
    let menuArea=document.getElementById("menu-area");

    if(menuArea.style.display==='none'){
        menuArea.style.display='block';
    }
    else{
        menuArea.style.display='none';
    }
}